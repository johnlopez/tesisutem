<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Exito</title>
</head>
<center>
<body>
<?=heading('El archivo se ha subido correctamente', 4);?>

<h5><?=anchor('files', 'Regresar'); ?></h5>
<h5><?=anchor('files/info', 'Listado de archivos para descargar'); ?></h5>

</body></center>
</html